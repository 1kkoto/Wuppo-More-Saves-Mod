#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
mkdir old
chmod +x xdelta3
./xdelta3 -v -d -s "data.win" "vcdiff/data.win.vcdiff" "datamod.win"
mv "data.win" old
